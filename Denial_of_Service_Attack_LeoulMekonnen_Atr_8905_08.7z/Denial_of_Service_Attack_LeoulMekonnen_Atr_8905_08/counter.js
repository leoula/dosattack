var express = require('express');
var counter = express();
counter.use(function(request,response,next){
    next();
});
counter.get('/', function(request,response){
    response.sendFile(__dirname +'/home.html');
}
);
// 
counter.get('/:testNumber',function(request,response){
    var number = parseInt(request.params['testNumber']);
    function Timer(n){
        var startTime = new Date().toUTCString();
        var counter = 0;
        while(counter < n){
            counter +=1;
        }
        var endTime = new Date().toUTCString();
        var timeSpan = startTime + " - " + endTime;
        return timeSpan;

    }
    response.send("The time it takes to count to "+ number +" is : " + Timer(number))
});
counter.listen(4500);